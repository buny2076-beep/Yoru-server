'use strict';
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const multer = require('multer');
const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.resolve(process.env.DATA_DIR || './data');
const MEDIA_DIR = path.join(DATA_DIR, 'uploads');
fs.mkdirSync(MEDIA_DIR, { recursive: true });
if (!process.env.UPLOAD_KEY || process.env.UPLOAD_KEY.length < 24) {
  console.error('FATAL: Set UPLOAD_KEY to a private random secret of at least 24 characters.');
  process.exit(1);
}
const db = new Database(path.join(DATA_DIR, 'yoru.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS media (
 id TEXT PRIMARY KEY, title TEXT NOT NULL, filename TEXT NOT NULL,
 mimetype TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now')),
 likes INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS comments (
 id INTEGER PRIMARY KEY AUTOINCREMENT, media_id TEXT NOT NULL,
 name TEXT NOT NULL, body TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now')),
 FOREIGN KEY(media_id) REFERENCES media(id) ON DELETE CASCADE
);
`);
db.pragma('foreign_keys = ON');
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false, crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(express.json({ limit: '32kb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use('/media', express.static(MEDIA_DIR, { maxAge: '1d', immutable: true, fallthrough: false }));
app.use(express.static(path.join(__dirname, 'public')));

const allowedMime = new Set(['image/jpeg','image/png','image/webp','image/gif','image/avif','video/mp4','video/webm','video/quicktime','video/ogg']);
const storage = multer.diskStorage({
 destination: (_req, _file, cb) => cb(null, MEDIA_DIR),
 filename: (_req, file, cb) => cb(null, crypto.randomUUID() + path.extname(file.originalname).toLowerCase().slice(0, 10))
});
const upload = multer({ storage, limits: { fileSize: 250 * 1024 * 1024, files: 5 }, fileFilter: (_req, file, cb) => cb(null, allowedMime.has(file.mimetype)) });
const requireUploadKey = (req, res, next) => {
 const key = req.get('x-upload-key') || '';
 const a = Buffer.from(key); const b = Buffer.from(process.env.UPLOAD_KEY);
 if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(401).json({ error: 'Неверный ключ загрузки.' });
 next();
};
const publicMedia = row => ({ id: row.id, title: row.title, src: '/media/' + encodeURIComponent(row.filename), video: row.mimetype.startsWith('video/'), likes: row.likes, createdAt: row.created_at });

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'YORU' }));
app.get('/api/media', (_req, res) => {
 const rows = db.prepare('SELECT * FROM media ORDER BY created_at DESC, rowid DESC LIMIT 300').all();
 const getComments = db.prepare('SELECT id,name,body AS text,created_at AS createdAt FROM comments WHERE media_id=? ORDER BY id ASC LIMIT 100');
 res.json(rows.map(row => ({ ...publicMedia(row), comments: getComments.all(row.id) })));
});
app.post('/api/media', requireUploadKey, (req, res) => {
 upload.array('files', 5)(req, res, err => {
  if (err) return res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? 'Файл больше лимита 250 МБ.' : 'Не удалось принять файлы. Поддерживаются изображения и обычные видеоформаты.' });
  if (!req.files || !req.files.length) return res.status(400).json({ error: 'Выбери до 5 файлов: JPG, PNG, WEBP, GIF, MP4 или WEBM.' });
  const insert = db.prepare('INSERT INTO media (id,title,filename,mimetype) VALUES (?,?,?,?)');
  const created = [];
  const tx = db.transaction(files => files.forEach(file => {
   const id = crypto.randomUUID();
   const title = path.basename(file.originalname, path.extname(file.originalname)).slice(0,70) || 'YORU';
   insert.run(id, title, file.filename, file.mimetype);
   created.push(publicMedia(db.prepare('SELECT * FROM media WHERE id=?').get(id)));
  }));
  try { tx(req.files); res.status(201).json(created); }
  catch (e) { req.files.forEach(f => { try { fs.unlinkSync(f.path); } catch (_) {} }); console.error(e); res.status(500).json({ error: 'Не удалось сохранить файлы.' }); }
 });
});
app.post('/api/media/:id/like', (req, res) => {
 const result = db.prepare('UPDATE media SET likes=MIN(likes+1,1000000000) WHERE id=?').run(req.params.id);
 if (!result.changes) return res.status(404).json({ error: 'Материал не найден.' });
 res.json({ likes: db.prepare('SELECT likes FROM media WHERE id=?').get(req.params.id).likes });
});
app.post('/api/media/:id/comments', (req, res) => {
 const media = db.prepare('SELECT id FROM media WHERE id=?').get(req.params.id);
 if (!media) return res.status(404).json({ error: 'Материал не найден.' });
 const name = String(req.body?.name || 'Гость').trim().replace(/[<>]/g, '').slice(0,40) || 'Гость';
 const body = String(req.body?.text || '').trim().slice(0,300);
 if (!body) return res.status(400).json({ error: 'Комментарий пустой.' });
 const result = db.prepare('INSERT INTO comments (media_id,name,body) VALUES (?,?,?)').run(req.params.id,name,body);
 res.status(201).json(db.prepare('SELECT id,name,body AS text,created_at AS createdAt FROM comments WHERE id=?').get(result.lastInsertRowid));
});
app.use((err, _req, res, _next) => { console.error(err); res.status(500).json({ error: 'Внутренняя ошибка сервера.' }); });
app.listen(PORT, '0.0.0.0', () => console.log(`YORU server listening on ${PORT}`));
